var SAMPLE_TIME_SERIES = [{
            name: 'Mon Capteur n°12345',
            data: [
              [1459514757000,12.10],
              [1459514767000,14.80],
              [1459514857000,17.50],
            ]}];
        

